import { Component } from '@angular/core';

@Component({
  selector: 'app-main-tree',
  templateUrl: './main-tree.component.html',
  styleUrls: ['./main-tree.component.scss']
})
export class MainTreeComponent {
ngOnInit(){
  console.log("coming o ntrro");
}
}
