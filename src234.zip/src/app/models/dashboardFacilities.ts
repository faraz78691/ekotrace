export  interface facilities {
    
        success: boolean,
        message: string,
        categories: [
            {
                ID: number,
                AssestName: string,
                "tenantID": string,
                id: string
            }
        ],
        status: number
    }
