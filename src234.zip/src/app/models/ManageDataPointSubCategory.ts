export class ManageDataPointSubCategory {
    id: number = 0;
    item: string;
    unit: string;
    isMandatory: boolean;
    active: boolean;
    subCatsavedID: number;
    SubCategorySeedID: number;
    categorySeedDataId: number;
}
