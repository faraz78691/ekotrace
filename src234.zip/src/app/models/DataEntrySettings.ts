export class DataEntrySetting {
  id: number;
  //tenantId: number;
  unit: string;
  lowerLimit: number;
  upperLimit: number;
  manageDataPointSubCategoriesID: number;
  //manageDataPointSubCategories?: ManageDataPointSubCategory;
}