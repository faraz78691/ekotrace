export class ForgotPassword {
    email: string;
    userId: string;
}
