export class licenseType{
    code:string='';
    name:string='';
}