export class CountryCode {
    
}
