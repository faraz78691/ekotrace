import { DisableScrollDirective } from './disable-scroll.directive';

describe('DisableScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new DisableScrollDirective();
    expect(directive).toBeTruthy();
  });
});
