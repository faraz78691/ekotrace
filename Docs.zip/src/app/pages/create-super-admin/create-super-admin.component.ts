import { Component } from '@angular/core';

@Component({
  selector: 'app-create-super-admin',
  templateUrl: './create-super-admin.component.html',
  styleUrls: ['./create-super-admin.component.scss']
})
export class CreateSuperAdminComponent {

}
