export class CompanyProfile {
    
}
