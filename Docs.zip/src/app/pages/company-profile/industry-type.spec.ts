import { IndustryType } from './industry-type';

describe('IndustryType', () => {
  it('should create an instance', () => {
    expect(new IndustryType()).toBeTruthy();
  });
});
