export class EmissionFactorTable {
    date = '';
    co2 = '';
    ch4 = '';
    n2o = '';
    tco2e = '';
    unit = '';
    user = '';
}