export class VehicleDEmode {
  id: number;
  modeName: string;
}