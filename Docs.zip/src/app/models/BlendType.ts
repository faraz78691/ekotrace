export class BlendType {
  id: number;
  typeName: string;
}