export interface facilities
{
    id:number,
    name:string
}-0