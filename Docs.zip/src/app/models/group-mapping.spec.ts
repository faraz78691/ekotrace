import { GroupMapping } from './group-mapping';

describe('GroupMapping', () => {
  it('should create an instance', () => {
    expect(new GroupMapping()).toBeTruthy();
  });
});
