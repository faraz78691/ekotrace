export class FacilityGroupList {
    id: number;
    name: string;
    flag: string;
}
