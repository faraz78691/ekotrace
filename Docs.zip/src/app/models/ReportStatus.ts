export class ReportStatus {
  FacilityName = '';
  CurrentStatus = ''; 
  Progress = '';
  Preparers = '';
  Managers = '';
  Approvers = '';
  Admins = '';
  Action = '';

}