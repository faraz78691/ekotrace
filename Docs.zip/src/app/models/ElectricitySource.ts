export class ElectricitySource {
  id: number;
  sourceName: string;
}