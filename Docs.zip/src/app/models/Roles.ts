export class RoleModel {
    id = "";
    name = "";
}
export class newRoleModel {
    Id = "";
    Name = "";
    categories:any[]=[]
}