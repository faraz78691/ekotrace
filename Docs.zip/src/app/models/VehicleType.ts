export class VehicleType {
  id: number;
  ID:number;
  vehicleType: string;
}