import { CompanyDetails } from './company-details';

describe('CompanyDetails', () => {
  it('should create an instance', () => {
    expect(new CompanyDetails()).toBeTruthy();
  });
});
