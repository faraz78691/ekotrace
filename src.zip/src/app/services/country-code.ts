export class CountryCode {
    
}
