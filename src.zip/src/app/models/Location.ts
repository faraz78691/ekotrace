export class Location {
  Name = '';
  shortName = '';
  Id: number
}