export class UserInfo {
    id: string;
    firstname = '';
    lastname = '';
    email = '';
    roleID = '';
    tenantId = '';
    password = '';
    username = '';
    facilityID: number = 0;
    facilityName = '';
    role = '';
    userID = '';
    isDisabledDelete = false;
    isDisabledEdit = false;

}
export class newUserInfo {
    id: string;
    firstname = '';
    lastname = '';
    email = '';
    roleID = '';
    tenantId = '';
    password = '';
    username = '';
    facilityID: number = 0;
    facilityName = '';
    role = '';
    userID = '';
    isDisabledDelete = false;
    isDisabledEdit = false;

}
