export class AssignedUser {
  username: string;
  email: string;
  firstname: string;
  lastname: string;
  role: string;
  roleID: string;
  rserID: string
}