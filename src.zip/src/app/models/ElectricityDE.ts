import { DataEntry } from "./DataEntry";

export class ElectricityDE extends DataEntry {
  sourceID: number;
  sourceName: string;
  electricityRegionID: number;
}