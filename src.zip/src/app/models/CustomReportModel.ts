export class CustomReportModel {
  dataPoint: string;
  April: string;
  May: string;
  June: string;
  July: string;
  August: string;
  September: string;
  October: string;
  November: string;
  December: string;
  January: string;
  February: string;
  March: string;
}