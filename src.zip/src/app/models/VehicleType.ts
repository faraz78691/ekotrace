export class VehicleType {
  id: number;
  vehicleType: string;
}