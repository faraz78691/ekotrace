 export class CountryCode {
  name: string;
  dialCode: string;
  currencySymbol:string;
  currencyCode:string;
 }