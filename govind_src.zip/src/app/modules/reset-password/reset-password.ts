export class ResetPassword {
    userid: any;
    oldpassword: any;
    newpassword: any;
    confirmpassword: any;
}
