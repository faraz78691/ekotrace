export class ViewrequestTable {
    category = '';
    datapoints = '';
    month= '';
    readingvalue= '';
    unit = '';
    status= '';
    action= '';
    details= '';
    
}