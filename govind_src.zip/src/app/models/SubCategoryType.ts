export class SubCategoryTypes {
  id: number;
  typeName: string;
  subCatID: number;
  subCatTypeID:number;
}