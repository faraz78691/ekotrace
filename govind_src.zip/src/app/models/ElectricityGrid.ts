export class ElectricityGrid {
  id: number;
  electricityRegionName: string;
}