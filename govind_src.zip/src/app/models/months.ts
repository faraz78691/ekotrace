export class months {
  january = false;
  february = false;
  march = false;
  april = false;
  may = false;
  june = false;
  july = false;
  august = false;
  september = false;
  october = false;
  november = false;
  december = false;
}