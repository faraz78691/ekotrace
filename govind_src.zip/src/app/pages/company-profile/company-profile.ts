export class CompanyProfile {
    
}
