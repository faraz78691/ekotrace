import { CountryCode } from './country-code';

describe('CountryCode', () => {
  it('should create an instance', () => {
    expect(new CountryCode()).toBeTruthy();
  });
});
