export class Units {
  id: number;
  unitName: string;
  seedsubcatID: number;
}