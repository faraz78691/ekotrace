export class TrackingTable {
    month = '';
    process = '';
    source= '';
    readingvalue= '';
    unit = '';
    totalghgEmission= '';
    energy= '';
    actions= '';
    status= '';
}