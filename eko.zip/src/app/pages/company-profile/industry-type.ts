export class IndustryType {
    value:string='';
    name:string='';
}
