import { CompanyProfile } from './company-profile';

describe('CompanyProfile', () => {
  it('should create an instance', () => {
    expect(new CompanyProfile()).toBeTruthy();
  });
});
