export class SavedDataPointSubCategory {
  id: number;
  manageDataPointSubCategorySeedID: number;
  item: string;
  isMandatory: boolean;
  active: boolean;
  TenantID: number;
  manageDataPointCategoriesId: number;
}