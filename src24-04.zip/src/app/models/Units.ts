export class Units {
  id: number;
  unitName: string;
  UnitName: string;
  seedsubcatID: number;
}