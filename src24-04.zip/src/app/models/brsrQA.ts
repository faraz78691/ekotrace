export class brsR_Q_As {
    id: number;
    question?: string;
    questionId: number;
    answer?: string;
    tenantId?: number;
    brsR_DocId?: number;
    principleID?: number;
}
