import { ManageDataPointSubCategories } from "./TrackingDataPointSubCategories";

export class DPType {
  typeName: string;
  manageDataPointSubCategories: ManageDataPointSubCategories[];
}